import { AppRegistry } from 'react-native';
import Integration from './App/src/Integration';
import App from './App'

AppRegistry.registerComponent('AwesomeProject', () => Integration);
