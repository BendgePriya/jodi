import React, { Component } from 'react';
import {Platform, View} from 'react-native';
import { InputsStack } from './components/Navigation/Navigation'
import Route from '../src/components/Navigation/Route'
import Tabs from '../src/components/Navigation/Navigation'
import Input from './components/TextInput/Inputs'
import SignUp from './components/TextInput/SignUp'

export default class Integration extends Component {
   render() {
      return (
            <InputsStack />      
      )
   }
}
