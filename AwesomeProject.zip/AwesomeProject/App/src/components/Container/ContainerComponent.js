import React, { Component } from 'react'
import { View } from 'react-native'
import PresentationalComponent from './PresentationalComponent'

export default class ContainerComponet extends Component {
      constructor(props){
            super(props)
            this.state = {
                myState: 'Initial State'
            }
        }
   updateState = () => {
      this.setState({ myState: 'The state is updated' })
   }
   render() {
      return (
         <View>
            <PresentationalComponent myState = {this.state.myState} updateState = 
               {this.updateState}/>
         </View>
      )
   }
}