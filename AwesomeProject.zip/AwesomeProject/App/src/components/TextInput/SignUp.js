import React, { Component } from 'react'
import {View, Text, TouchableOpacity, TextInput, StyleSheet } from 'react-native'

export default class SignUp extends Component{
    constructor(props){
        super(props)
        this.state = {
            email: '',
            password: '',
            profileFor:'',
            fullName:'',
            dateOfBirth:'',
            mobileNo:''
        }
        this.handleCancel = this.handleCancel.bind(this)
    }
    handleEmail = (text) => {
        this.setState({ email: text })
     }
     handlePassword = (text) => {
        this.setState({ password: text })
     }
     handleProfileFor = (text) => {
      this.setState({ profileFor: text })
    }
   handleFullName = (text) => {
      this.setState({ fullName: text })
   }
   handleDateOfBirth = (text) => {
    this.setState({ dateOfBirth: text })
  }
 handleMobileNo = (text) => {
    this.setState({ mobileNo: text })
 }
     login = (email, pass) => {
        alert('email: ' + email + ' password: ' + pass)
        this.validate(this.state.email)
        this.isRequired()
     }
     handleCancel(){
        this.setState({email: ''})
        this.setState({password: ''})
      }
      validate = (text) => {
        if (text !== '')
        {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
        if(reg.test(text) === false)
        {
        alert('Email is Not Correct');
        this.setState({email:text})
        return false;
          }
        else {
          this.setState({email:text})
          alert('Email is Correct');
        }
        }
        }
        
        isRequired = () => {  
          if(this.state.email === '' || this.state.password === '' || this.state.profileFor === '' ||
          this.state.fullName === '' || this.state.dateOfBirth === '' || this.state.mobileNo === ''){
            alert('Please Fill the required field')
          }
        }
    render(){
        return(
            <View style = {styles.container}>
            <Text style = {styles.signUp}> Sign Up </Text>
            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "Email"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handleEmail}
            value = {this.state.email}/>

            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "Password"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handlePassword}
            secureTextEntry = {true} 
            value = {this.state.password}/>

            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "Create Profile For"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handleProfileFor}
            secureTextEntry = {true} 
            value = {this.state.profileFor}/>

            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "Full Name"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handleFullName}
            secureTextEntry = {true} 
            value = {this.state.fullName}/>

            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "date Of Birth"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handleDateOfBirth}
            secureTextEntry = {true} 
            value = {this.state.dateOfBirth}/>

            <TextInput style = {styles.input}
            underlineColorAndroid = "transparent"
            placeholder = "Mobile Number"
            placeholderTextColor = "#9a73ef"
            autoCapitalize = "none"
            onChangeText = {this.handleMobileNo}
            secureTextEntry = {true} 
            value = {this.state.mobileNo}/>

            <View style = {styles.container2}>
            <TouchableOpacity style = {styles.submitButton}
            onPress = {
                () => this.login(this.state.email, this.state.password)
             }>
             <Text style = {styles.submitButtonText}> Register Me </Text>
          </TouchableOpacity>
          <TouchableOpacity style = {styles.submitButton}
            onPress = { this.handleCancel }>
             <Text style = {styles.submitButtonText}> Cancle </Text>
          </TouchableOpacity>
          </View>
            </View>
        )
    }
}

const styles = StyleSheet.create(
    {
        signUp: {
            marginTop: 20,
            textAlign: 'center',
            color: 'blue',
            fontWeight: 'bold',
            fontSize: 20
         },
        container: {
            paddingTop: 23
        },
        container2: {
            flexDirection: 'row',
            justifyContent: 'flex-end',
            alignItems: 'center'
         },
        input: {
            margin: 13,
            height: 40,
            borderColor: '#7a42f4',
            borderWidth: 1
        },
        submitButton: {
            backgroundColor: '#7a42f4',
            padding: 10,
            margin: 15,
            height: 40,
            
        },
        submitButtonText: {
            color: 'white',
            textAlign: 'center'
        }
    }
)