import React, { Component } from 'react'
import { Image } from 'react-native'

export default class ImageTestLocal extends Component {
    render(){
        return (
            <Image source = {require('../../img/img2.jpeg')} 
            style = {{ width: 200, height: 200 }} />
        )
    }
}

