import React, { Component } from 'react';
import {Text, View, StyleSheet, ScrollView } from 'react-native'

export default class ScrollViewExample extends Component{
    constructor(props){
        super(props)
        this.state = {
            names: [
                {
                    'name' : 'Parag',
                    'id' : 1
                },
                {
                    'name' : 'Priya',
                    'id' : 2
                },
                {
                    'name' : 'Prayag',
                    'id' : 3
                },
                {
                    'name' : 'Riya',
                    'id' : 4
                }
            ]
        }
    }
    render() {
        return (
            <View>
                <ScrollView>{
                    this.state.names.map((item,index) => (
                        <View key = {item.id} style = {styles.item}>
                        <Text> {item.name}</Text>
                        </View>
                    ))
                }
                </ScrollView>
            </View>
        )
    }
}
const styles = StyleSheet.create(
    {
        item: {
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: 15,
            margin: 2,
            borderColor: '#2a4944',
            borderWidth: 1,
            backgroundColor: '#d2f7f1'
        }
    }
)