import React, { Component } from 'react'
import { View } from 'react-native'
import PresComponent from './PresComponent'

export default class ContainerComponet extends Component {
      constructor(props){
            super(props)
            this.state = {
                myState: 'Initial State'
            }
        }
   updateState = () => {
      this.setState({ myState: 'The state is updated' })
   }
   render() {
      return (
        <View>
        <PresComponent myState = {this.state.myState} callBack = {this.updateState} />
     </View>
      )
   }
}
