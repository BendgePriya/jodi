import React, { Component } from 'react'
import { Text, View, StyleSheet} from 'react-native'

const PresComponent = (props) => {
   return (
      <View>
         <Text style = {styles.myState} onPress = {props.callBack}>
            {props.myState}
         </Text>
      </View>
   )
}
export default PresComponent

const styles = StyleSheet.create ({
   myState: {
      marginTop: 20,
      textAlign: 'center',
      color: 'blue',
      fontWeight: 'bold',
      fontSize: 20
   }
})