import React, {Component} from 'react'
import Input from '../TextInput/Inputs'
import SignUp from '../TextInput/SignUp'
import { StackNavigator } from 'react-navigation'

const Route = StackNavigator({
    Input: { screen: Input},
    SignUp: { screen: SignUp}
    },
)

export default Route