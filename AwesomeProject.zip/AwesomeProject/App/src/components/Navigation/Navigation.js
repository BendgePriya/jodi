import React from 'react';
import {TabNavigator, StackNavigator } from 'react-navigation';
import Inputs from '../TextInput/Inputs';
import SignUp from '../TextInput/SignUp';

export const InputsStack = StackNavigator({
  Inputs: {
    screen: Inputs,
    navigationOptions: {
      title: 'SignIn',
    },
  },
  SignUp: {
    screen: SignUp,
    navigationOptions: ({ navigation }) => ({
      title: 'SignUp',
    }),
  },
});

export const Tabs = TabNavigator({
  Inputs: {
    screen: InputsStack,
    navigationOptions: {
      tabBarLabel: 'Feed',
      tabBarIcon: ({ tintColor }) => <Icon name="list" size={35} color={tintColor} />,
    },
  },
  SignUp: {
    screen: SignUp,
    navigationOptions: {
      tabBarLabel: 'Me',
      tabBarIcon: ({ tintColor }) => <Icon name="account-circle" size={35} color={tintColor} />
    },
  },
});

export const Root = StackNavigator({
  Tabs: {
    screen: Tabs,
  },
}, {
  mode: 'modal',
  headerMode: 'none',
});