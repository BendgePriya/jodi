import React, { Component } from 'react';
import { Text, View } from 'react-native';

export default class Home extends Component{
    constructor(props){
        super(props)
        this.state = {
            myState: 'Initial State'
        }
        //this.updateState = this.updateState.bind(this)
    }
    updateState = () => {
        this.setState({ myState: 'The state is updated' })
    }
    render(){
        return(
            <View>
                <Text onPress = {this.updateState}>
                    {this.state.myState}
                </Text>
            </View>
        )
    }
}